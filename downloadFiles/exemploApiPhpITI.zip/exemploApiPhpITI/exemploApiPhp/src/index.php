<!DOCTYPE html>
<html>
<body>

<form action="upload.php" method="post" enctype="multipart/form-data">
    Selecione arquivo para fazer o upload: <br>
    <div style="padding-top:10px;"><input type="file" name="fileToUpload" id="fileToUpload"> <br></div>
    <div style="padding-top:10px;"><input type="submit" value="Upload Arquivo" name="submit"> <br></div>
</form>

</body>
</html>
